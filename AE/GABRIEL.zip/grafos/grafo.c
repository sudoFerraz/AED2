#include "grafo.h"

struct Grafo {
    int NumVertices;
    int NumArestas;
    TipoPeso **Mat;
};

TipoGrafo* Cria_Grafo(int NVertices) {

    int i, k;
    TipoGrafo *Grafo;

    if(NVertices <= 0) return NULL;

    Grafo = (TipoGrafo*) malloc(sizeof(TipoGrafo));
    if(Grafo == NULL) return NULL;

    Grafo->Mat = (TipoPeso**) malloc(NVertices*sizeof(TipoPeso*));
    if(Grafo->Mat == NULL) {
        free(Grafo);
        return NULL;
    }

    for(i=0; i<NVertices; i++) {

        Grafo->Mat[i] = (TipoPeso*) calloc(NVertices, sizeof(TipoPeso));
        if(Grafo->Mat[i] == NULL) { /// N�o conseguiu alocar a linha i da matriz

                for(k=0; k<i; k++) { /// Libera linhas previamente alocadas
                    free(Grafo->Mat[k]);
                }

                free(Grafo);
                return NULL;
        }

    }

    Grafo->NumVertices = NVertices;
    Grafo->NumArestas = 0;

    return Grafo;
}

int Insere_Aresta(TipoGrafo *Grafo, TipoVertice v1, TipoVertice v2, TipoPeso peso) {

    if(Grafo == NULL) return -1;

    if(Grafo->Mat[v1][v2] != 0 || peso == 0) return 0;

    Grafo->Mat[v1][v2] = peso;
    Grafo->NumArestas++;

    return 1;
}

int Existe_Aresta(TipoGrafo *Grafo, TipoVertice v1, TipoVertice v2) {

    if(Grafo==NULL) return -1;
    if(Grafo->Mat[v1][v2]==0) return 0;

    else return 1;

}

int Retira_Aresta(TipoGrafo *Grafo, TipoVertice v1, TipoVertice v2) {
    if(Grafo==NULL) return -1;

    if(Grafo->Mat[v1][v2]==0) return 0;

    Grafo->Mat[v1][v2] = 0;
    Grafo->NumArestas --;

    return 1;
}

int Consulta_Aresta(TipoGrafo *Grafo, TipoVertice v1, TipoVertice v2, TipoPeso *peso) {
    if(Grafo==NULL) return -1;

    if(Grafo->Mat[v1][v2]==0) return 0;

    *peso = Grafo->Mat[v1][v2];

    return 1;
}

void Mostra_Lista_Adjacentes(TipoGrafo* Grafo, TipoVertice v) {

    int i, cont = 0;

    if(Grafo == NULL)
        printf("\nGrafo inexistente.");
    else {

        printf("\nLista de vertices adjacentes a %4d: ", v);
        for(i=0; i < Grafo->NumVertices; i++) {

            if(Grafo->Mat[v][i] != 0) {
                printf("%4d", i);
                cont = 1;
            }

        }

        if(cont == 0) printf("\nO vertice %d nao possui vertices adjacentes.", v);
    }

}

void Mostra_Grafo(TipoGrafo* Grafo) {

    int i,j;

    if(Grafo == NULL || Grafo->NumArestas == 0) {
        printf("\nGRAFO NAO EXISTE OU NAO POSSUI ARESTAS.");
    }else {

        for(i=0; i<Grafo->NumVertices; i++) {
            printf("\nVERTICES ADJACENTES A %4d --- ", i);

            for(j = 0; j < Grafo->NumVertices; j++) {
                if(Grafo->Mat[i][j] != 0) {
                    printf("%4d", j);
                }
            }
        }

    }

}

TipoGrafo* Libera_Grafo(TipoGrafo* Grafo) {

    int i;
    if(Grafo == NULL) return NULL;

    for(i=0; i<Grafo->NumVertices; i++)
        free(Grafo->Mat[i]);

    free(Grafo->Mat);
    free(Grafo);
    Grafo = NULL;

    return Grafo;
}
