#include <stdio.h>
#include <stdlib.h>
#include "grafo.h"

int main()
{

    TipoGrafo* Grafo;
    TipoVertice v1, v2;
    TipoPeso peso;
    int n, opt, res;

    do {

        printf("\n              GRAFOS            ");
        printf("\n================================");
        printf("\n1. CRIAR GRAFO");
        printf("\n2. INSERIR ARESTA");
        printf("\n3. VERIFICAR SE ARESTA EXISTE");
        printf("\n4. REMOVER ARESTA");
        printf("\n5. CONSULTAR ARESTA");
        printf("\n6. MOSTRAR LISTA DE ADJACENTES");
        printf("\n7. MOSTRAR GRAFO");
        printf("\n8. LIBERAR GRAFO");
        printf("\n0. SAIR");
        printf("\n================================");
        printf("\nDIGITE UMA OPCAO: ");
        scanf("%d", &opt);
        printf("================================");


        switch(opt) {

            case 1: ///CRIA GRAFO

                printf("\nNUMERO DE VERTICES: ");
                scanf("%d", &n);

                Grafo = Cria_Grafo(n);

                if(Grafo != NULL) {
                    printf("\nGRAFO CRIADO COM SUCESSO !");
                }

                break;

            case 2: ///INSERIR ARESTA

                printf("\nVERTICE 1: ");
                scanf("%d", &v1);

                printf("\nVERTICE 2: ");
                scanf("%d", &v2);

                printf("\nPESO DA ARESTA: ");


                scanf("%d", &peso);

                if(Insere_Aresta(Grafo, v1, v2, peso) == 1)
                    printf("\nARESTA INSERIDA COM SUCESSO !");
                else
                    printf("\nERRO AO INSERIR ARESTA.");

                break;

            case 3: ///VERIFICA SE ARESTA EXISTE

                printf("\nVERTICE 1:");
                scanf("%d", &v1);

                printf("\nVERTICE 2:");
                scanf("%d", &v2);

                res = Existe_Aresta(Grafo, v1, v2);

                if(res == -1)
                    printf("\nGRAFO INEXISTENTE !");
                else if(res == 1)
                    printf("\nARESTA EXISTENTE !");
                else
                    printf("\nARESTA INEXISTENTE !");

                break;

            case 4: ///REMOVER ARESTA

                printf("\nVERTICE 1:");
                scanf("%d", &v1);

                printf("\nVERTICE 2:");
                scanf("%d", &v2);

                res = Retira_Aresta(Grafo, v1, v2);

                if(res == -1)
                    printf("\nGRAFO INEXISTENTE !");
                else if(res == 0)
                    printf("\nARESTA INEXISTENTE !");
                else
                    printf("\nARESTA REMOVIDA !");

                break;

            case 5: ///CONSULTAR ARESTA

                printf("\nVERTICE 1:");
                scanf("%d", &v1);

                printf("\nVERTICE 2:");
                scanf("%d", &v2);

                res = Consulta_Aresta(Grafo, v1, v2, &peso);

                if(res == -1)
                    printf("\nGRAFO INEXISTENTE !");
                else if(res == 0)
                    printf("\nARESTA INEXISTENTE !");
                else
                    printf("\nPESO DA ARESTA: %d", peso);

                break;

            case 6: ///MOSTRAR LISTA DE ADJACENTES

                printf("\nVERTICE: ");
                scanf("%d", &v1);

                Mostra_Lista_Adjacentes(Grafo, v1);

                break;

            case 7: ///MOSTRAR GRAFO

                Mostra_Grafo(Grafo);

                break;

            case 8: ///LIBERAR GRAFO

                if(Libera_Grafo(Grafo) == NULL) {
                    printf("\nGRAFO LIBERADO !");
                }else{
                    printf("\nERRO AO LIBERAR GRAFO !");
                }

                break;

        }

        printf("\n================================");
        printf("\nDIGITE UMA OPCAO : ");
        scanf(&opt);

    } while(opt != 0);

}
